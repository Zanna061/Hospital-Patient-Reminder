/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMain.java to edit this template
 */
package file_demo;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class WriteToFile {

    public static void main(String[] args) {
        String path = "emp_record.txt";
        // String record = "100, James Doe From Windhoek";
        String record = "101, James Doe From Swakopmund";
        try {
                //FileWriter fw = new FileWriter(path);
                FileWriter fw = new FileWriter(path, true);
                fw.write(record);
                    System.out.println("Record write successful");
                                fw.close();
        } catch (IOException e) {
            System.out.println("An error occured...");
        }
    }
}
