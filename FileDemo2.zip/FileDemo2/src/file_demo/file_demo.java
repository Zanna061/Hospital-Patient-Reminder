/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMain.java to edit this template
 */
package file_demo;

import java.io.File;
import java.io.IOException;

public class file_demo {

    public static void main(String[] args) {
        File file = new File("emp_record.txt");
        try {
            if (file.createNewFile()) {
                System.out.println("File created Successfully");
            } else {
                System.out.println("File creation error...");

            }
        } catch (IOException e) {
            System.out.println("An error occured...");
        }
    }
}
