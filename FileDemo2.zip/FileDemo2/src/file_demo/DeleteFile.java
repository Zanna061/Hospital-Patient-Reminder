package file_demo;

import java.io.File;

public class DeleteFile {

    public static void main(String[] args) {
        File file = new File("emp_record.txt");
        if (file.delete()) {
            System.out.println("File: " + file.getName() + "deleted successfully");
        } else {
        System.out.println("File not deleted");
       }
    }
}
