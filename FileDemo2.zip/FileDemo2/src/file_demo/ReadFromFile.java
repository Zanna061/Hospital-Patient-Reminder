package file_demo;

import java.io.IOException;
import java.io.FileReader;

public class ReadFromFile {

    public static void main(String[] args) {
        String path = "emp_record.txt";
        char[] record = new char[200];

        try {
            FileReader fr = new FileReader(path);
            fr.read(record);
            System.out.println("File Read successfull");
            System.out.println(record);
            fr.close();
        } catch (IOException e) {
            System.out.println("An error occured...");
        }
    }
}
